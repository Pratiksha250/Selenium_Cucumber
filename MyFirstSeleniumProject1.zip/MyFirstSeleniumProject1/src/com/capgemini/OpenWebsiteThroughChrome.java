package com.capgemini;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenWebsiteThroughChrome {

	public WebDriver initialSettings() {
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\pdhandar\\Desktop\\3\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		return driver;
//		
//		driver.get("http://www.google.com");
//		System.out.println("Opened successfully");
//		driver.quit();
	}
		
		
	
	
}
