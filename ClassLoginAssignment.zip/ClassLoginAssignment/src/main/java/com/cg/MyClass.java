package com.cg;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MyClass {

	
	public static void main(String[] args) {
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\pdhandar\\Desktop\\3\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:\\D:\\Module 3\\ClassLoginAssignment\\src\\main\\webapp\\Index.html");
		
		WebElement username = driver.findElement(By.id("username"));
		username.sendKeys("tom");
		
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys("jerry");
		
		WebElement btn = driver.findElement(By.xpath("//*[@id=\"commit\"]"));
		btn.click();
		
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());

		
		
		
		
	}
}
