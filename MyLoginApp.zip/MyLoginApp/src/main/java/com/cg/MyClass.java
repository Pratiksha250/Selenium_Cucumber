package com.cg;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MyClass {

	
	public static void main(String[] args) {
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\pdhandar\\Desktop\\3\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:\\D:\\Module 3\\MyLoginApp\\src\\main\\webapp\\Index.html");
		//driver.get("http://www.google.com");
		
		WebElement fname = driver.findElement(By.xpath("//*[@id=\"fName\"]"));
		fname.sendKeys("Pratiksha");
		
		WebElement lname = driver.findElement(By.id("lName"));
		lname.sendKeys("Dhandi");
		
		WebElement gender = driver.findElement(By.id("phonenumber"));
		gender.sendKeys("7387678820");
		
		WebElement country = driver.findElement(By.id("Country"));
		Select select = new Select(country);
		select.selectByVisibleText("China");
		
		WebElement date = driver.findElement(By.id("date"));
		Select selectdate = new Select(date);
		selectdate.selectByVisibleText("2");
		
		WebElement month = driver.findElement(By.id("month"));
		Select selectmonth = new Select(month);
		selectmonth.selectByVisibleText("Apr");
		
		WebElement year = driver.findElement(By.id("year"));
		Select selectyear = new Select(year);
		selectyear.selectByVisibleText("1995");
	
		List<WebElement> radiobuttons = driver.findElements(By.name("gender"));
		radiobuttons.get(1).click();
		
		WebElement uname = driver.findElement(By.name("user"));
		uname.sendKeys("prd@gmail.com");
		
		WebElement pw = driver.findElement(By.id("password1"));
		pw.sendKeys("helloAdmin");
		
		WebElement pw2 = driver.findElement(By.id("password2"));
		pw2.sendKeys("helloAdmin");
		
		WebElement sec = driver.findElement(By.id("emailID2"));
		sec.sendKeys("prd@hotmail.com");
		
		WebElement accept = driver.findElement(By.id("tick"));
		accept.click();
		
		WebElement btn = driver.findElement(By.id("ok"));
		btn.submit();
		
		
		
		
		
		
	}
}
