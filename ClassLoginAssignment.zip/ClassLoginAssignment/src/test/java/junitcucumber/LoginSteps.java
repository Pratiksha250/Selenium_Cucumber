package junitcucumber;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {

	private WebDriver driver;
	
//	@Before
//	public void init() {
//		
//	
//	}
	
	@Given("^User is on loginPage$")
	public void funcOne() throws Throwable{
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\pdhandar\\Desktop\\3\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:\\D:\\Module 3\\ClassLoginAssignment\\src\\main\\webapp\\Index.html");
		
	}
	
	@Then("^user has entered (.*) as the username$")
	public void fun2(String user) {
		driver.findElement(By.id("username")).sendKeys(user);
		
	}
	
	@And("^user has entered (.*) as the password$")
	public void fun3(String pw) {
		driver.findElement(By.id("password")).sendKeys(pw);
		
	}
	
	@When("^user presses login$")
	public void fun4() {
		driver.findElement(By.xpath("//*[@id=\"commit\"]")).click();
	}
	
	@Then("^the result should be (.*) on the screen$")
	public void fun5(String result) {
		Alert alert = driver.switchTo().alert();
		String a=alert.getText();
		assertEquals(result, a);

	}
	
}
