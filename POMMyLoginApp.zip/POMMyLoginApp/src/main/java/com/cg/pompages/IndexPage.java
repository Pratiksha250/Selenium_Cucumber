package com.cg.pompages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class IndexPage {

	@FindBy(how=How.XPATH, using="//*[@id=\"fName\"]")
	public WebElement fname;
	
	@FindBy(how=How.ID, using="lName")
	public WebElement lname;
	
	@FindBy(how=How.CSS, using="#phonenumber")
	public WebElement phone;
	
	public static Select country(WebDriver driver) {
		WebElement country = null;
		country=driver.findElement(By.id("Country"));
		Select select = new Select(country);
		return select;
	}
	
	public static Select dateDay(WebDriver driver) {
		WebElement dates = driver.findElement(By.id("date"));
		Select select = new Select(dates);
		return select;
	
	}
	
	public static Select dateMonth(WebDriver driver) {
		WebElement months = driver.findElement(By.id("month"));
		Select select = new Select(months);
		return select;
		
	}
	
	public static Select dateYear(WebDriver driver) {
		WebElement months = driver.findElement(By.id("year"));
		Select select = new Select(months);
		return select;

	}
	
	public static List<WebElement> gender(WebDriver driver) {
		List<WebElement> radiobuttons = driver.findElements(By.name("gender"));
		return radiobuttons;
	}
	
	public static WebElement userID(WebDriver driver) {
		WebElement user=null;
		user=driver.findElement(By.name("user"));
		return user;
	}
	public static WebElement password(WebDriver driver) {
		WebElement pword=null;
		pword=driver.findElement(By.id("password1"));
		return pword;
	}
	public static WebElement confirmPassword(WebDriver driver) {
		WebElement pword2=null;
		pword2=driver.findElement(By.id("password2"));
		return pword2;
	}
	
	public static WebElement email2(WebDriver driver) {
		WebElement mail=null;
		mail=driver.findElement(By.id("emailID2"));
		return mail;
	}
	
	public static WebElement tick(WebDriver driver) {
		WebElement element1 = null;
		element1=driver.findElement(By.id("tick"));
		return element1;
		
	}
	public static WebElement submit(WebDriver driver) {
		WebElement submitButton=driver.findElement(By.id("ok"));
		return submitButton;
		
	}


}
