package com.cg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.pompages.IndexPage;

public class MyClass {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","D:\\Users\\pdhandar\\Desktop\\3\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:\\D:\\Module 3\\MyLoginApp\\src\\main\\webapp\\Index.html");

		IndexPage page = PageFactory.initElements(driver, IndexPage.class);
		
		
		page.fname.sendKeys("Jane");
		page.lname.sendKeys("Austen");
		page.phone.sendKeys("7410852963");
		

		IndexPage.country(driver).selectByIndex(2);
		
		IndexPage.dateDay(driver).selectByIndex(2);
		IndexPage.dateMonth(driver).selectByIndex(2);
		IndexPage.dateYear(driver).selectByIndex(2);
		
		IndexPage.gender(driver).get(1).click();
		
		IndexPage.userID(driver).sendKeys("jane21@gmail.com");
		
		IndexPage.confirmPassword(driver).sendKeys("malala");
		IndexPage.password(driver).sendKeys("malala");
		
		IndexPage.email2(driver).sendKeys("abc@in.com");
		
		IndexPage.tick(driver).click();
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1500);
		IndexPage.submit(driver).click();

		
		
		
		
		
		
		


	}
}
