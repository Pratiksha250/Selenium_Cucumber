package com.capgemini;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginCheck {
	
	
	public static void main(String[] args) {
		
		OpenWebsiteThroughChrome oc=new OpenWebsiteThroughChrome();
		WebDriver driver=oc.initialSettings();
		
		driver.get("https://github.com/login");

		String userName="YourCorrectUsername";
		String passWord="YourCorrectPassword";
		
		WebElement field1 = driver.findElement(By.id("login_field"));
		field1.sendKeys(userName);
		WebElement field2 = driver.findElement(By.id("password"));
		field2.sendKeys(passWord);
		field1.submit();
		
		if(driver.getCurrentUrl().equalsIgnoreCase("https://github.com/"))
			System.out.println("Logged in successfully");
		else
			System.out.println("Incorrect credentials");
		
	}
		
	
}
