package com.capgemini;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FirstScript {
public static void main(String[] args) {
	
	OpenWebsiteThroughChrome oc=new OpenWebsiteThroughChrome();
	WebDriver driver=oc.initialSettings();
	
	
	driver.get("http://www.google.com");
	WebElement searchField = driver.findElement(By.id("lst-ib"));
	searchField.sendKeys("pluralsight");
	searchField.submit();
	System.out.println("Success");
	
	WebElement imagesLink = driver.findElement(By.linkText("Images"));
	imagesLink.click();
	
	//driver.quit();
	
	
	
	
	
}
}
